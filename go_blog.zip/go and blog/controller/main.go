package controller

import (
 	
	"go_blog/models"
	"go_blog/models/blog"
	"go_blog/models/catalog"

	"net/http"
	"github.com/gin-gonic/gin"
)
/**
 *@Author guobin
 *@See catalog、blog package
 *@Data 2018/03/17
 *
 */

func main() {
	gin.SetMode(gin.DebugMode) 
	router := gin.Default()

	router.GET("/findCatalog", FindCatalog)
	router.POST("/edit", Edit)
	router.GET("/delete", Delete)
	router.GET("/queryArticle", QueryArticle)
	router.Run()
    
	err := http.ListenAndServe(":8080", nil)    
	if err != nil {    
        log.Fatal("ListenAndServe: ", err.Error())    
    }  

}
//文章列表查询
func FindCatalog(c *gin.Context){

	cat,err  := catalog.All()
	if err != nil {
		c.String("查询失败"+err.Error())
		return
	}
	c.Data["Catalogs"] = cat

	c.Layout = "layout/frame.html"
	c.TplName = "catalog/findCata.html"
}

//文章编辑（通过文章的Id）
func Edit(c *gin.Context) {
	id, err := c.Param("id")
	if err != nil {
		c.String("编辑失败"+err.Error())
		return
	}

	b := blog.SelectById(int64(id))
	if b == nil {
		c.String("没有此文章")
		return
	}
	//设置变量保存数据
	c.Data["Content"] = ReadBlogContent(b).Content
	c.Data["Blog"] = b
	c.Data["Catalogs"] = catalog.All()
	// layout 设计，整个管理界面不变，只会变化中间部分 在页面中通过{{.LayoutContent}}嵌入
	//这里省去了两个页面的编写
	c.Layout = "layout/frame.html"
	//被嵌入到admin.html的页面
	c.TplName = "article/edit.html"
}


//文章删除（根据所选中的文章Id进行删除）
func Delete(c *gin.Context) {
	//通过点击删除时的动作获取相对应文章的编号id
	id, err := c.Param("id")
	if err != nil {
		c.String("get param id fail"+err.Error())
		return
	}
/*
这里导入了blog包下的方法，所以可以直接使用OneById的方法
而id是models模型中的id属性，通过id查找相应的模型对象，下同。
*/
	b := blog.SelectById(int64(id))
	if b == nil {
		c.String("can't find!")
		return
	}

	err = blog.Del(b)
	if err != nil {
		c.String("Delete fail! "+err.Error())
		return
	}

	c.String("Delete successful!")
	return
}

//文章查看
func QueryArticle(c *gin.Context){
	id, err := c.Param("id")
	if err != nil {
		c.String("the param id not exist"+err.Error())
		return
	}

	b := blog.SelectById(int64(id))
	if b == nil {
		c.String("no such article")
		return
	}
	c.Data["Content"] = blog.ReadBlogContent(b).Content 
	c.Layout = "layout/frame.html"
	c.TplName = "catalog/queryArt.html"
}