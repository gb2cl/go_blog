package test

import (
	"testing"
	"github.com/gin-gonic/gin"
	"net/http"
	"net/http/httptest"
	"fmt"
	"io"
)

var router

func init(){ 
	router = gin.Default()

	router.GET("/findCatalog", findCatalog)
	router.POST("/edit", Edit)
	router.GET("/delete", Delete)
	router.GET("/queryArticle", QueryArticle)
}


func TestfindCatalog(t *testing.T) {
	//
	url := "/findCatalog"
	req := httptest.NewRequest("GET",url,nil)
	w := httptest.NewRecorder()
	router.ServerHTTP(w,req)
        result := w.Result()
        defer result.Body.Close()

        body,_ := ioutil.ReadAll(result.Body)   
	fmt.Printf("response:%v\n",string(body))
        html,_ := ioutil.ReadFile("C:/resources/go/findCatalog.html")
        htmlStr := string(html)

        if htmlStr != string(body) {
              t.Errorf("��Ӧ���ݲ�����body:%v\n",string(body))
       }
}


func TestEdit(t *testing.T,) {
	url := "/edit"
	
	param := make(map[string]string)
	param["Title"] = "cat"
	param["Content"] = "I don't know you ,but I fall in love at first sight."
	param["Created"] = time.Time
	param["Type"] = 1
	
	req := httptest.NewRequest("POST", url+ParseToStr(param), nil)
	w := httptest.NewRecorder()
	router.ServeHTTP(w, req)
	result := w.Result()
        defer result.Body.Close()
	body, _ := ioutil.ReadAll(result.Body)
	fmt.Printf("response:%v\n", string(body))
	response := &LoginResponse{}
        if err := json.Unmarshal(body, response); err != nil {
              t.Errorf("�������ֳ�����err:%v\n",err)
        }
        if response.Data.Title != "cat" {
              t.Errorf("��Ӧ���ݲ����߼���username:%v\n",response.Data.Username)
        }
}

func TestDelete(t *testing.T) {
	url := "/delete"
	req := httptest.NewRequest("GET",url,nil)
	w := httptest.NewRecorder()
	router.ServerHTTP(w,req)
	//
        result := w.Result()
        defer result.Body.Close()

        /
        body,_ := ioutil.ReadAll(result.Body)   
	fmt.Printf("response:%v\n",string(body))
	if string(body) != "Delete successful!" {
              t.Errorf("Error��body:%v\n",string(body))
       }
}

func TestQueryArticle(t *testing.T) {
	url := "/queryAritle"
	req := httptest.NewRequest("GET",url,nil)
	w := httptest.NewRecorder()
	router.ServerHTTP(w,req)
        result := w.Result()
        defer result.Body.Close()

        body,_ := ioutil.ReadAll(result.Body)   
	fmt.Printf("response:%v\n",string(body))
        html,_ := ioutil.ReadFile("C:/resources/go/queryAritle.html")
        htmlStr := string(html)

        if htmlStr != string(body) {
              t.Errorf("���ݲ�����body:%v\n",string(body))
       }
}

type EditResponse struct {
       Errno string `json:"errno"`
       Errmsg string `json:"errmsg"`
       Data Blog `json:"data"`
}
